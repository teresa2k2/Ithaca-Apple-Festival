# Project 1: Design Journey

**For each milestone, complete only the sections that are labeled with that milestone.** Refine all sections before the final submission.

You are graded on your design process. If you later need to update your plan, **do not delete the original plan, leave it in place and append your new plan _below_ the original.** Then explain why you are changing your plan. Any time you update your plan, you're documenting your design process!

**Replace ALL _TODOs_ with your work.** (There should be no TODOs in the final submission.)

Be clear and concise in your writing. Bullets points are encouraged.

**Everything, including images, must be visible in _Markdown: Open Preview_.** If it's not visible in the Markdown preview, then we can't grade it. We also can't give you partial credit either. **Please make sure your design journey should is easy to read for the grader;** in Markdown preview the question _and_ answer should have a blank line between them.


## Existing Design (Milestone 1)

**Make the case for your decisions using concepts from class, as well as other design principles, theories, examples, and cases from outside of class (includes the design prerequisite for this course).**

You can use bullet points and lists, or full paragraphs, or a combo, whichever is appropriate. The writing should be solid draft quality.

### Existing Site: The Site (Milestone 1)
> What is your existing site about? Tell us about it.

My existing site is about Ithaca Apple Harvest Festival. It serves as a website to provide college students in Ithaca more information about the event. 

> How and where did you create this site?

I created this in INFO 1300 class using HTML, CSS, and Java-Script

> Is this site designed for desktop, mobile devices or both?

Both 

> Explain with this website is a **static** website.

This website is a static website because the contents displayed on the website does not change based on the user. 

### Existing Site: Audience (Milestone 1)
> Briefly explain your site's audience.
> Be specific and justify why this audience is a **cohesive** group.

My site's audience is undergraduate college students in Ithaca city. This is a cohesive group because many undergraduate students tend to attend the Ithaca Apple Harvest Festival with friends at least once in their undergraduate year. Additonally, many of them get there by either walking or bus and often do not really know what to expect.

### Existing Site: Audience Goals (Milestone 1)
> Document your existing site's audience's goals. (These should be informed by user research. Not assumptions or stereotypes.)
> List each goal below. There is no specific number of goals required for this, but you need enough to do the job (Hint: It's more than 1 and probably more than 2).

Goal 1: To know what they can expect to find at the festival 

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - I will add a list of multiple shops and food vendors to the website.
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - Adding a list of shops will help the user learn more about what type of things are available to be purchased at the festival. Adding a list of food vendors will help the user know what kind of food they can expect to find at the event. These will help the user decide if it is worth investing their time to attend the event and help them plan accordingly. 

Goal 2: To know how to get there

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - I will add a short description of how people get there as well as a map.
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - The map will help the user get an idea of where the festival is, how far it is from their current location, and what method of transportation are available. The short description will help the user know the most popular methods and feel safer taking their method of transportation. 

Goal 3: To know when to go there

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - I will add a short description of the time of event as well as the busier times of the day
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This will help the user know exactly when the event will take place as well as plan what time of day they would like to attend the event based on if they want to meet a lot of people there or not. 




### Existing Site: Design/Sketches (Milestone 1)
> Sketch your existing site. Include these sketches here.
> **You may not copy your sketches from a previous assignment.**
> Why can't you copy the sketches? I want to get you thinking about the strengths/weaknesses of the current design.
> Provide an explanation _underneath_ each sketch explaining the sketch and any design patterns you are leveraging.

 ![home](home.jpg)
 
The above sketch is a sketch of my homepage. This page includes general information about the event as well as time and location and some images to aid the user get an idea of the vibes of the event. In this page, I leverge design patterns such as repitition, contrast and simplicity. I used bold color background with a white box for the contents. This helps the user give their attention to important information. I keep it simple to allow the user to focus on the event and content instead what the website looks like. I also use the repetiton by keeping the font and the size the same. 

 ![food](food.jpg)
 
The above is a sketch of my food and drinks page. This page leverages repetition and alignment. I utilized the same font, structure, and font size for both the food and drink section so that the user can easily navigate through the page and find relative information. 

 ![shop](shop.jpg)
 
The above is a sketch of shops page. This page again leverages repition as I wanted the user to be able to navigate easily and find desired information as easily as possible. 

 ![faq](faq.jpg)
 
The above sketch is of my FAQ's page. While this page looks a little bit different from the rest of the page, I leveraged repetition again by applying the maroon-ish color when hover over the accordion so that the user know they are still on the same website. I also tried to maximize the use of space by creating accordion for each question so the user can find relavant questions easily. 


## Milestone 1 Feedback Revisions (Milestone 2)
> Explain what you revised in response to the Milestone 1 feedback

I accidently submitted a wrong commit number for my milestone one. Therefore, I was not able to recieve any feedback. 


## Refined Design (Milestone 2)

### Refined Design: Persona (Milestone 2)
> Use the goals you identified above from your prior user research to develop a persona of your site's audience.
> Your persona must have a name and a face. The face can be a photo of a face or a drawing, etc.
> You may type out the persona below with bullet points or include an image of the persona. Just make sure it's easy to read the persona when previewing markdown.

 ![persona](persona.jpg)

-Persona's Name: Elizabeth

-Device: Desktop

-Factors Influencing Elizabeth's Behavior: classes, workload, food, income, transportation, accepted payment method, friends

-Elizabeth's Goals: To have good time with friends, to eat good food, to try new food and drinks, and to get to the event prepared. 
-Elizabeth's Needs: flexible payment methods, flexible time because have some work to do over the weekend, public transportation because  does not own a car, does not have a lot of money left to spend
-Elizabeth's Wants: to be able to pay with card or phone, public transportation to get there, inexpensive food/drinks

### Refined Design: Mobile or Desktop (Milestone 2)
> Will your refined design be functional on mobile, tablet, or desktop devices?

Desktop

### Refined Design: Form Brainstorm (Milestone 2)
> Brainstorm ideas for collecting data from your persona on your website.
> The form must support the persona's goals when using the website.
> For each form idea, explain how the form supports the goals of the persona.
> **Refer to the persona by name.**

1) Contact Form:

Contact form would allow Elizabeth to reach out to the Ithaca Apple Fesitval organizers and ask for any clarifications. This supports the goals' of Elizabeth because her one of her goals is to eat good food, so she can ask if their would a particular type of food and how much that food cost. 

2) Reviews Form:

One of Elizabeth's goals is to have fun at the festival, it would be helpful to her to know other people's experience at the festival and whether it seems like a festival that she and her friends would find entertaining. 

3) Order Form

One of Elizabeth's goals is to eat good food, so it would be helpful to her if she is able to order food ahead of time so that she knows for sure she will have her food once she arrives at the festival. 



### Refined Design: Content (Milestone 2)
> List **all** the content you plan to include your website for your **persona**.
> You should list all types of content you planned to include (i.e. text, photos, images, etc.)
> List the content here. Label the content as "(new)" if it's new to the existing site.

- general information about event
- time and place of event 
- images of food
- images of drinks
- images of craft shops
- list of some food
- list of some drinks
- list of some craft shops 
- q&a accordion
- contact form (new)
- carousel of general images


### Refined Design: Content Justification (Milestone 2)
> Explain why this content supports the goals of your persona.
> **Refer to the persona by name.**

These contents support Elizabeth's goals because the texts and images and carousel will give Elizabeth a general idea of what type of food and drinks are available at the event. The accordion will help answer any common questions she may have and the contact form will let Elizabeth get her specific questions answered so she can arrive to the festival prepared. Images and list of craft shops will give Elizabeth a general idea of what she and her friends can do at the event to have fun. 


### Refined Design: Content Organization (Milestone 2)
> Organize the content for the audience and identify possible pages for the content using **multiple iterations** of card sorting.
> Include photographic evidence of each iteration of card sorting **and** a explanation of your thought process for each iteration.
> **Please physically sort cards;** please don't try and do this digitally.
> **Refer to the persona by name.**

Iteration 1
 ![iteration1](iteration1.jpg)
 
For this iteration, I decided to put all vendor related things in one place: food, drinks, and crafts. I decided that it would be a good idea to include all the event related content in one page and the contact form seperately. I thought this organization would make sense for Elizabeth since she would want to find all her desired information in a single page. 
 
Iteration 2:
 ![iteration2](iteration2.jpg)
 
For iteration 2, I decided to split up the vendor relating contents into two different pages. One with the food and drinks and one with just the crafts. I thought this would make more sense for elizabeth since people usually think of food & drink together but doesn't really associate crafts with it. I decided to split the event related information two groups as well: one with general and the other with year specific information. I thought this would make sense for Elizabeth since she is more interested in being prepared for the event over knowing the history of the event. 

Iteration 3:
  ![iteration3](iteration3.jpg)
  
For iteration 3, I decided to group the time and place event with general information because I think the specific time and place would be more important to Elizabeth since she may have some work to do over the weekned, so It would be helpful for her to know that she has options on which date she choose to go. 


### Refined Design: Navigation (Milestone 2)
> Please list the pages you will include in your website's navigation.

- Ithaca Apple Festival
- Food & Drinks
- Crafts 
- FAQ's
- Contact

> Explain why the names of these pages make sense for your persona.

Ithaca Apple Harvest Festival makes sense for Elizabeth because as a college/university student she has probably seen many websites that uses their name as navigation for their homepage, so she will probably expect to find general information about the event there. Food & Drinks makes sense for Elizabeth because she will be looking for what type of food or drinks are at the festival since she hopes to find good food at the event. Crafts makes sense for Elizabeth since she is looking for something fun to do with her friends. FAQ's makes sense for Elizabeth since she is a college/university student so she will most likely understand the acronym stands for Frequently Asked Questions and look for questions relavent to her.   

### Refined Design: Design (Milestone 2)
> Refine the design of your site to address the goals of your persona.
> Include iterations of **sketches** for each page of the refined design.
> Provide a brief explanation _underneath_ each sketch.
> Document your _entire_ design process. **Show your preliminary sketches and your final sketches.** **We want to see iteration!**
> **Refer to your persona by name in each explanation.**

  ![home](home.jpg)
  
For my homepage, I was comtemplating between two designs. The biggest difference is my one has the time information only in the homepage and the other has it as a header so it shows up in everypage. Previously, I had the time near the bottom of the page. But here I decided to prioritize it since Elizabeth needs to find the date to know if she can attend the event admist her workload. I decided to go with the one where it only shows on the homepage because when Elizabeth navigates through the website, she probably is not looking for the same information on every page and the date at the top on every page may be distracting. P
  
  ![foodndrinks](foodndrinks.jpg)
  
For food and drinks, I had three ideas. My first idea was to aligh the images of food and the list of food and same thing for the drinks. I thought this would be easy for Elizabeth to navatigate through the page and see if there's food or dirnks she might like to try. My second idea is also very similar, but instead of aliging the images to the left, I aligned them to the right. For my third idea, I was thinking of creating a wheel of imgages of food and drinks with labels already attached to them. I thought this would make it fun for Elizabeth to go through the options. I decided to go with my second idea because I think it would help attract ELizabeth more to attend the event if she sees images of the food first instead of the names of the food. 

  ![crafts](crafts.jpg)
  
For the crafts page, I also had three ideas. My first idea was to creat a sliding gallery of the images of craft shops with labels in them. I thought this would be help Elizabeth see many pictures of craft shops at once. My second idea involves creating a list with an image for the craft shops. I thought this would make it easy for Elizabeth to see what shops she might like. My third idea involves creating an image carousel. I thought this help Elizabeth connect the craft shop names with the images directly
 
  ![faqs](faqs.jpg)
  
For my FAQ's page, I had three ideas. All three ideas involve creating an accordion. However, they differ in where the signs are placed. The first and second one differs in the signs used and the second and third differs in the space between the question boxes. I thought these ideas make sense for Elizabeth since she probably wants to find the answer to her questions in the fastest manner. However, I went with the third idea because I thought it needed some space between the question boxes and the plus and minus signs are more used nowadays so it might make it easier for Elizabeth to understand the function as she might see it used more often. 


  ![contact](contact.jpg)

For the contact page, I had three ideas. All three desings include a textfield for name and email, textarea for their question, and a submit button. While all three designs are pretty similar, their difference lies in where labels are placed. The first one placed the labels on the left side of the text boxes while the second and third placed the labels on the top of the text boxes. However, while the second one placed the submit button on the left, the third one placed it on the right. Ultimately, I decided to go with the third choice since the labels on top of the textboxes are more used nowadys, so Elizabeth might find it easier to locate and comprehend the labels. Additionally, the button on the right would make more sense for Elizabeth since people scan texts from left to right and up and down. 

  ![confirmation](confirmation.jpg)

For the confirmation page, I was contemplating between placing the texts at the left of the page or on the center of the page. I decided that middle would be better for Elizabeth since she already since it will allow her to see it on the center of her screen right as she after she submits her answer. Additionally, it will be similar format to the FAQ's page, so Elizabeth will feel more comfortable navigating between pages.

 ![error](error.jpg)
 
For the error page, I had two ideas. One with the message on the corner and one in the middle. I decided to go with the middle since I want Elizabeth to feel comfortable changing between pages. In addition, since the FAQ and confirmation page are centered, Elizabeth will more likely expect to see the text in the center. 


  ![finaldesign](finaldesign.jpg)

This is my final design. I put together all the pages I designed to the same navigation style and body style I chose for my homepage. This makes sense for Elizabeth because it will direct her eyes to content that matters to her most. I also made sure every page carry similar style choices so that Elizabeth knows she is still on the same website. I also ended up deciding to add a footer to let Elizabeth know that page has ended and should navigate to other pages to find her desired information. 


### Partial Plan (Milestone 2)
> Using your refined sketches, plan your site's partials.
> You may describe each partial or sketch it. It's up to you!
> Explain how you will customize at least 1 partial.

I will make my header and footer as partials. I will create a new folder called "includes." There, I will create a file called "header.php" and "footer.php". I will call the header.php and footer.php into every php file I created. I will then customize the header in CSS to make sure there's a colored box that indicates to the Elizabeth which page she is currently viewing. 

## Milestone 2 Feedback Revisions (Milestone 3)
> Explain what you revised in response to the Milestone 2 feedback

I recevied positive feedback on every section in milestone 2, so I did not revise anything in response to milestone 2 feedback. However, I am redesigning my form, confirmation, and 404 page to fit Elizabeth's needs better. 

## Form Design and Planning (Milestone 3)

### Refined Form Design (Milestone 3)
> Refine the design of your site's form to address the goals of your persona.
> Include iterations of **sketches** of the form and its confirmation message.
> Provide a brief explanation _underneath_ each sketch.
> **Refer to the persona by name.**

  ![contacts](contacts.jpg)
  
I had three design ideas for redesigning my form. The first idea is that I keep everything the same as my previous design because it does fit Elizabeth's needs as it provides a page that is similar to other pages of the website. My second idea is to shorten the length of the box for name and place it by email as it will inform Elizabeth the name she inputs does not need to be long. My third idea is that I will align the textboxes with the labels side by side since Elizabeth is accessing this form from a desktop so there is adaquate horizontal space. 

  ![contactsfinal](contactsfinal.jpg)
  
Ultimately, I went with my second idea because it will inform Elizabeth of the number of letters expected for each category and make good use of the horizontal space by placing the textfield for the name and email together. 

Additionally, I decided to change the textfield to email for type in the email textbox. 

  ![confirmations](confirmations.jpg)

In redefining my content arrangement for the confirmation page, my first idea was to align all the contents to the left because Elizabeth may scan the left first for text contents since most 404 pages have their text contents on the left side of the page. My second idea is to include the information she filled out and label the heading as "Confirmation" instead because this will inform Elizabeth of exactly what the reciever will see. My third idea is similar to my second but with label "Got it!" instead to let Elizabeth know they got her question. 

  ![confirmationsfinal](confirmationsfinal.jpg)
  
I decided to go with my first idea because most websites only show you a message that they got your message and will respond soon. Therefore, Elizabeth may be confused by seeing all the information she entered and be suspicious of the credibility of the website. 

   ![confirmationfinal2](confirmationfinal2.jpg)

I decided go with my second idea instead but with "Thank you" for heading 1. This is because I think Elizabeth would appreciate knowing whether she entered her email or message accurately so she can decide if she needs to send the message again incase she doesn't recieve response as soon as she hoped.

### Form Planning (Milestone 3)
> Will your form use a GET or POST request.
> Justify your decision as to why the request type is appropriate for the form.

I will use POST request. This is appropriate form for Elizabeth as she might not be okay with the public having access to her full nume, email address, or the question/request she submitted as the question/request may contain personal information too. 

### Refined Missing Resource Page (Milestone 3)
> Refine the design of your site's missing resource 404 page for your persona.
> Include iterations of **sketches** of the page.
> Provide a brief explanation _underneath_ each sketch.
> **Refer to the persona by name.**


  ![lostpage](lostpage.jpg)

I had three ideas for redefining my 404 page. My first idea is to move the contents to align left because it is more common for 404 pages' texts to align on the left, so Elizabeth might first scan on the left side to find the information. My second idea is align the content to the left and change the heading to "Whoops" instead as Elizabeth might not know what 404 means. 

  ![lostpagefinal](lostpagefinal.jpg)
  
 I decided to continue with the second idea because Elizabeth may not be a tech-savy student, so she might be confused by what the 404 page indicates. 
  
  
## Milestone 3 Feedback Revisions (Final Submission)
> I changed the type of input for the user's email to "email." I also output everything the user input on the confirmation page.


## Complete & Polished Website (Final Submission)

### Routing (Final Submission)
> Plan your HTTP routing.
> List each route and the PHP file for each route.

| Route                     | PHP File                            |
| -----------               | ----------------------------------- |
| /                         | pages/index.php                     |
| /foodndrinks              | pages/foodndrinks.php               |
| /crafts                   | pages/crafts.php                    |
| /faqs                     | pages/faqs.php                      |
| /contacts                 | pages/contacts.php                  |
| /contacts/confirmation    | pages/confirmations.php             |

> Explain why these routes (URLs) are usable for your persona.

These routes are usable for Elizabeth because they are word for word the navigation title for each page. This will help ensure Elizabeth that she is on the right page and will help her get to the page she wants to without any confusion. 

### Accessibility Audit (Final Submission)
> Tell us what issues you discovered during your accessibility audit.
> What do you do to improve the accessibility of your site?

I discovered that the arrows for my carousels are not accessiblity. I fixed this issue by changing the white colored arrow to a dark red colored arrow with white background. This worked because the image and arrows are more contrasting now so it is easier for users to locate the arrow. 

### Final Design + Audience Goals (Final Submission)
> Tell us how your final site addresses the gaols of the audience.
> Be specific. Tell us how you tailored your design, content, etc. to make your website usable for your persona.
> **Refer to the persona by name.**

My final design addresses Elizabeth's goals because it provides her in a very direct and simple manner of the date and background of the festival, what type of food and drinks are sold at the festival, what fun shops they have at the festival, how to get there, what type of payment they accept, and other common questions she may have. It also provides her with pictures of the event so she knows what to expect at the festival. She also has a place to ask any other questions that are not addressed in the website. Therefore, Elizabeth has everything she needs to decide when she can attend the event, if the event offer food and fun worth attending, and what she would need to prepare if she choose to attend the event. 

### Self-Reflection (Final Submission)
> Take some time here to reflect on how much you've learned since you started this class. It's often easy to ignore our own progress. Take a moment and think about your accomplishments in this class. Hopefully you'll recognize that you've accomplished a lot and that you should be very proud of those accomplishments!

I learned how to emphanthize with my persona and brainstorm and implement a dynamic website that would be most beneficial for my user. 


## Grading (Final Submission)

### Grading: Mobile or Desktop (Final Submission)
> When we grade your final site, should we grade this with a mobile screen size or a desktop screen size?

desktop


### Grading: Partials (Final Submission)
> Clearly list each partial file and where you used it.

- header.php 
  I use it in every page. 
- footer.php
  I use it in every page. 

> Which partials have customization? Explain how the customization looks in the browser.

- header.php is highlighted in black on every page. 


### Collaborators
> List any persons you collaborated with on this project.

I did not collaborate with anyone on this project. 

### Reference Resources
> Please cite any external resources you referenced in the creation of your project.
> (i.e. W3Schools, StackOverflow, Mozilla, etc.)

I did not use any external sources.
