


  $("#question1").click(function() {
    if ($("#answer1").hasClass("active")) {
      $("#answer1").removeClass("active");
    } else {
      $("#answer1").addClass("active");
    }
  });

  $("#question2").click(function() {
    if ($("#answer2").hasClass("active")) {
      $("#answer2").removeClass("active");
    } else {
      $("#answer2").addClass("active");
    }
  });

  $("#question3").click(function() {
    if ($("#answer3").hasClass("active")) {
      $("#answer3").removeClass("active");
    } else {
      $("#answer3").addClass("active");
    }
  });

  $("#question4").click(function() {
    if ($("#answer4").hasClass("active")) {
      $("#answer4").removeClass("active");
    } else {
      $("#answer4").addClass("active");
    }
  });

  $("#qna1").click(function() {
  if ($("#qna1").hasClass("active")) {
    $("#qna1").removeClass("active");
  } else {
    $("#qna1").addClass("active");
  }
});

$("#qna2").click(function() {
  if ($("#qna2").hasClass("active")) {
    $("#qna2").removeClass("active");
  } else {
    $("#qna2").addClass("active");
  }
});

$("#qna3").click(function() {
  if ($("#qna3").hasClass("active")) {
    $("#qna3").removeClass("active");
  } else {
    $("#qna3").addClass("active");
  }
});

$("#qna4").click(function() {
  if ($("#qna4").hasClass("active")) {
    $("#qna4").removeClass("active");
  } else {
    $("#qna4").addClass("active");
  }
});
