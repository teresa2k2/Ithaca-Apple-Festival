<?php $crafts = 'active'; ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>


<body>
<main>

<h1>CRAFT SHOPS</h1>
<div class="craftshop">
<figure>
<!-- Source: instructure provided -->
    <img
    src="/public/images/craftwood.jpg" alt="Wood Crafts"  />
  </figure>
<ul>
<!-- Source: instructure provided -->
    <li>  A&K Creations</li>
<li>  Alchemist's Whim</li>
<li>  All Forked Up Art</li>
<li>  Anna Pausch Studios</li>
<li>  Art Of Yen Ospina</li>
<li>  Ashley Messana Jewelry</li>
<li>  Bags That Bite</li>
<li>  Black Rabbit Studio</li>
<li>  Blue Toucan Studios Fairy Doors</li>
<li>  Bon Fire Craft</li>
<li>  Soaps & Sundries</li>
<li>  MV CERAMICS</li>
<li>  Natalie Rae NY</li>
<li>  Pair'adox Dice</li>
<li>  Pam Gifford Pottery</li>
<li>  Pickled Punks</li>
<li>  Pm Press</li>
<li>  potsbydjr</li>
<li>  Puccoon Raccoon</li>
<li>  Queen City Basement Designs</li>
 </ul>
</div>
</main>

<?php include("includes/footer.php") ?>

</body>
</html>
