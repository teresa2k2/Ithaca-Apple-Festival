<?php $foodndrinks = 'active'; ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>


<body>
<main>
    <h1>FOOD</h1>
    <div class="food">
    <figure>
      <!-- Source: instructor provided -->
        <img
        src="/public/images/donuttrays.jpg" alt="Donut Trays" id="foodimg"  />
      </figure>
    <ul> <li>Farm Fresh Apples</li>
        <li>Donuts</li>
        <li>Pies</li>
        <li>Bakeries</li>
        <li>Mexican Crusine</li>
        <li>Japanese Dishes</li>
        <li>Thai Dishes</li>
        <li>BBQ Style Dishes</li>
      </ul>
      </div>

      <h1>DRINKS</h1>
      <div class="drinks">
    <figure>
      <!-- Source: instructor provided -->
        <img
        src="/public/images/ciderapplesstand.jpg" alt="Apple Ciders Stand"  />
      </figure>
    <ul>
        <li>Ciders</li>
        <li>Wines</li>
        <li>Lemonades</li>
        <li> Pops</li>
    </ul>
      </div>

</main>
<?php include("includes/footer.php") ?>

</body>
</html>
