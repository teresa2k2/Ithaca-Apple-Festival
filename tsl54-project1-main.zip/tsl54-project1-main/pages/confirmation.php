<?php
$name = $_POST['namespace'];
$email = $_POST['emailspace'];
$message = $_POST['messagespace'];
?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>


<body>
<main>

<h1>Thank You!</h1>
<p> We received your message and will get back to you as soon as we can! </p>

<div class="feedback" >

    <h3> Information Received</h3>
    <p> Below is the information we recieved from you. Please make sure to double check your email as we will be getting back to you through the email you provided! </p>

</div>

<div class="input" >
    <h5>Name:</h5>
        <p><?php echo htmlspecialchars($name); ?></p>
    <h5>Email:</h5>
        <p><?php echo htmlspecialchars($email); ?></p>
    <h5>Message:</h5>
        <p><?php echo htmlspecialchars($message); ?></p>
</div>

</main>

<?php include("includes/footer.php") ?>

</body>
</html>
