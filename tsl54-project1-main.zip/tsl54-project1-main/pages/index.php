<?php $home = 'active'; ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>

<body>
<main>
  <div class="home">

  <h1>Date & Time</h1>
  <ul><!-- Source: instructure provided -->
    <li>Friday, September 30: 12pm - 6pm </li>
    <li>Saturday, October 1: 10am - 6pm </li>
    <li>Sunday, October 2: 10am - 6pm</li>
  </ul>

<h1>What is the Ithaca Apple Festival?</h1>
<p> <!-- Source: instructor provided -->
Over 100 talented artists, crafters, bakers, and makers come together for the Apple Harvest Craft Fair! Find creative, unique works from clothing to woodworking, ceramics to paintings, fudge to essential oils and beyond throughout the festival. The festival is held in the Ithaca Commons, a few streets that are full of restaurants and shops.Since 1982, the Ithaca Apple Harvest Festival hosts apples, baked goods, family entertainment, games, prizes, live entertainment and more. </p>

<div class="carousel">
  <button class="carousel-button" id="prev" >&#10094;</button>
  <button class="carousel-button" id="next" >&#10095;</button>

      <!-- Source: instructure provided -->
       <img class="slide" id="slide1"
       src="/public/images/peopleeatingapples.jpg" alt="People Eating Apples"  />
      <!-- Source: instructure provided -->
      <img class="slide hidden" id="slide2"
         src="/public/images/commons.jpg" alt="People at Commons"  />
      <!-- Source: https://theithacan.org/ -->
        <img class="slide hidden" id="slide3"
         src="/public/images/peoplesellingapples.jpg" alt="People at Apple Cider Stand"  />
</div>
</div>

</main>
<?php include("includes/footer.php") ?>

  <script src="/public/scripts/jquery-3.6.1.js"></script>
  <script src="/public/scripts/imagecarousel.js"></script>

</body>

</html>
