<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>


<body>
<main>

    <h1>Whoops!</h1>

    <p>It seems the page you are looking for does not exist! Please check your spelling on the URL and try again!</p>

</main>

<?php include("includes/footer.php") ?>

</body>
</html>
