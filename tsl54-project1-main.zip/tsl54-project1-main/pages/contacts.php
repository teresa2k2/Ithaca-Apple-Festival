<?php $contacts = 'active'; ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>


<body>
<main>

<h1>Contact Us With Any Questions!</h1>

<form id="contact" method="post" action="/contacts/confirmation"  novalidate>

<div class="all-labels">

    <div class="form-labels">
        <div class="name-label">
            <label for="name">Name:</label>
            <input type="textfield" name="namespace" id="name" />
        </div>
        <div class="email-label">
            <label for="email">Email:</label>
            <input type="email" name="emailspace" id="email" />
        </div>
    </div>

    <div class="message-label">
        <label for="message">Message:</label>
        <input type="textarea" name="messagespace" id="message" />
    </div>

    <div class="submit-label">
        <input id="submitbutton" type="submit" value="Submit" />
    </div>

</div>
</form>

</main>

<?php include("includes/footer.php") ?>

</body>
</html>
