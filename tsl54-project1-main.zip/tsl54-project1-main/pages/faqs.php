
<?php $faqs= 'active'; ?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/header.php") ?>

<body>
<main>
  <div class="faqs">


      <h1> Frequently Asked Questions </h1>
<div class="accordion">
    <div class="qna" id="qna1">
        <div class="question" id="question1">
            <h3>How Do I Get  to the Festival? </h3></div>
        <div class="answer" id="answer1">
          <p>A lot of guests arrive to the festival by walking or taking a bus! Check out the
          <!-- Source: instructor provided -->
          <a href="/public/images/tcat.pdf">
          TCAT Fall 2022 Schedules</a> for bus information!</p>
          <p>Below is an image of  Ithaca commons to help you navigate the event!</p>
          <!-- Source: instructor provided -->
          <img
          src="/public/images/map.png" alt="Map of Ithaca Commons"  />
     </div>
    </div>
    <div>
    </div >
    </div>

      <div class="qna" id="qna2">
        <div class="question" id="question2">
            <h3>What payment methods are accepted?</h3></div>
        <div class="answer" id="answer2">
            <p>Cash is the preferred method of payment for most vendors. There are a few vendors that may accept venmo or card as payment method.</p>
          </div>
        </div>

          <div class="qna" id="qna3">
        <div class="question" id="question3">
           <h3>What is the price range of the vendors? </h3>
          </div>
          </div>

        <div class="answer" id="answer3">
            <p>This varies from vendor to vendor. You may spot apple cider donuts for as low as $2.00, but you may also find art pieces that sell for over $500.</p>
          </div>
        </div>

        <div class="qna" id="qna4">
        <div class="question" id="question4">
            <h3>How busy is the festival?</h3> </div>
        <div class="answer" id="answer4" >
            <p>Lines tend to be shorter in the morning, but the length of waiting time for each vendor varies. </p>
          </div>


</div>
</main>
<?php include("includes/footer.php") ?>

<script src="/public/scripts/jquery-3.6.1.js"></script>
<script src="/public/scripts/faqs.js"></script>

</body>
</html>
