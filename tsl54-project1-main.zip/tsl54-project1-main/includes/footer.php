<footer>
    <h3>made with love </h3></footer>
