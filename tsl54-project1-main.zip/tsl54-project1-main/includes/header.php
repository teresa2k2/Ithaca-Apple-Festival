<head>
  <meta charset="UTF-8" />
  <title class="Ithaca Apple Harvest Festival">Ithaca Apple Harvest Festival</title>

  <link rel="stylesheet" type="text/css" href="/public/styles/site.css" media="all" />


    <nav>
        <ul>

          <li class="<?php echo $home; ?>"><a href="/">Ithaca Apple Harvest Festival</a></li>
          <li class="<?php echo $foodndrinks; ?>"><a href="/foodndrinks">Food & Drinks</a></li>
          <li class="<?php echo $crafts; ?>"><a href="/crafts">Crafts</a></li>
          <li class="<?php echo $faqs; ?>"><a href="/faqs">FAQ'S</a></li>
          <li class="<?php echo $contacts; ?>"><a href="/contacts">Contact</a></li>

        </ul>
    </nav>
</head>
